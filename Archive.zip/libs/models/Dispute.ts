import { BigNumber } from "ethers";

export class Dispute {
  reason: string = "";
  timestamp: BigNumber = BigNumber.from("-1");
}
