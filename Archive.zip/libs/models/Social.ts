import { BigNumber } from "ethers";
import { Freelancer } from "./Freelancer";

export class Social {
  name: string = "";
  url: string = "";
}
