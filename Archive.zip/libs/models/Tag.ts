import { BigNumber } from "ethers";

export class Tag {
  id: BigNumber = BigNumber.from("-1");
  name: string = "";
}
