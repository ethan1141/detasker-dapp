import { BigNumber } from "ethers";

export class ShowcaseWork {
  id: BigNumber = BigNumber.from("-1");
  description: string = "";
  url: string = "";
}
