/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  useFileSystemPublicRoutes: false,
  swcMinify: true,

  env: {
    API_URL: "http://127.0.0.1:8545/",
    API_KEY: "",
    PRIVATE_KEY:
      "0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80",
    CONTRACT_ADDRESS: "0x748fb668Bc170661250eF69052a90fED2c3Da1B1",
    summary:
      "Detasker is a decentralized application (dApp) that uses smart contracts to facilitate peer-to-peer transactions between users who post jobs and those who complete them. Similar to Airtasker, users can post a job they need done, specify the requirements and the price they are willing to pay for the service. Other users can then search and find jobs that match their skills and interests, and offer to complete the job for the agreed-upon price. The use of smart contracts ensures that the terms of the job are automatically enforced by the blockchain, providing a high level of trust and transparency for all parties involved. Detasker is an innovative solution for decentralized freelancing and task completion, leveraging the power of blockchain technology to provide secure and efficient services.",
    usp: "Detasker offers a decentralized and trustless platform for freelancers and job seekers, leveraging the power of smart contracts to ensure that tasks are completed securely, efficiently, and with transparency.\n\nWith Detasker, users can find and complete jobs that match their skills and interests while enjoying a high level of trust and flexibility in a peer-to-peer environment",
    security:
      "As a decentralized platform, Detasker uses advanced security measures to ensure that all transactions are safe and secure.\n\nThe use of smart contracts helps to eliminate the need for intermediaries, reducing the risk of fraud and ensuring that the terms of the job are automatically enforced.",
  },
};

module.exports = nextConfig;
