export default function Listings() {
  return <div></div>;
}
