export default function PostAJob() {
  return <div></div>;
}
